import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from mysql.connector import Error
import hashlib
from datetime import date

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "port": 3306
}
DB_NAME = "scholarship_finder"

SAMPLE_SCHOLARSHIPS = [('Computer Science Scholarship (BS) - 01',
  'Global Technology Education Fund',
  'United Kingdom',
  'BS',
  'Computer Science',
  8000,
  'USD',
  '2027-01-05',
  'Sample technology funding for BS students in Computer Science. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Computer Science Scholarship (MS) - 02',
  'Global Technology Education Fund',
  'United States',
  'MS',
  'Computer Science',
  10000,
  'USD',
  '2027-02-06',
  'Sample technology funding for MS students in Computer Science. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Information Technology Scholarship (MS) - 03',
  'Global Technology Education Fund',
  'Germany',
  'MS',
  'Information Technology',
  12000,
  'USD',
  '2027-03-07',
  'Sample technology funding for MS students in Information Technology. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Information Technology Scholarship (PhD) - 04',
  'Global Technology Education Fund',
  'Japan',
  'PhD',
  'Information Technology',
  15000,
  'USD',
  '2027-04-08',
  'Sample technology funding for PhD students in Information Technology. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Software Engineering Scholarship (BS) - 05',
  'Global Technology Education Fund',
  'Australia',
  'BS',
  'Software Engineering',
  18000,
  'USD',
  '2027-05-09',
  'Sample technology funding for BS students in Software Engineering. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Software Engineering Scholarship (MS) - 06',
  'Global Technology Education Fund',
  'Canada',
  'MS',
  'Software Engineering',
  8000,
  'USD',
  '2027-06-10',
  'Sample technology funding for MS students in Software Engineering. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Data Science Scholarship (MS) - 07',
  'Global Technology Education Fund',
  'Türkiye',
  'MS',
  'Data Science',
  10000,
  'USD',
  '2027-07-11',
  'Sample technology funding for MS students in Data Science. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Data Science Scholarship (PhD) - 08',
  'Global Technology Education Fund',
  'China',
  'PhD',
  'Data Science',
  12000,
  'USD',
  '2027-08-12',
  'Sample technology funding for PhD students in Data Science. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Artificial Intelligence Scholarship (BS) - 09',
  'Global Technology Education Fund',
  'Malaysia',
  'BS',
  'Artificial Intelligence',
  15000,
  'USD',
  '2027-01-13',
  'Sample technology funding for BS students in Artificial Intelligence. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Artificial Intelligence Scholarship (MS) - 10',
  'Global Technology Education Fund',
  'Italy',
  'MS',
  'Artificial Intelligence',
  18000,
  'USD',
  '2027-02-14',
  'Sample technology funding for MS students in Artificial Intelligence. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Medicine Scholarship (BS) - 11',
  'Global Health Education Fund',
  'United Kingdom',
  'BS',
  'Medicine',
  8000,
  'USD',
  '2027-03-15',
  'Sample medical funding for BS students in Medicine. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Medicine Scholarship (MS) - 12',
  'Global Health Education Fund',
  'United States',
  'MS',
  'Medicine',
  10000,
  'USD',
  '2027-04-16',
  'Sample medical funding for MS students in Medicine. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Nursing Scholarship (MS) - 13',
  'Global Health Education Fund',
  'Germany',
  'MS',
  'Nursing',
  12000,
  'USD',
  '2027-05-17',
  'Sample medical funding for MS students in Nursing. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Nursing Scholarship (PhD) - 14',
  'Global Health Education Fund',
  'Japan',
  'PhD',
  'Nursing',
  15000,
  'USD',
  '2027-06-18',
  'Sample medical funding for PhD students in Nursing. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Pharmacy Scholarship (BS) - 15',
  'Global Health Education Fund',
  'Australia',
  'BS',
  'Pharmacy',
  18000,
  'USD',
  '2027-07-19',
  'Sample medical funding for BS students in Pharmacy. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Pharmacy Scholarship (MS) - 16',
  'Global Health Education Fund',
  'Canada',
  'MS',
  'Pharmacy',
  8000,
  'USD',
  '2027-08-20',
  'Sample medical funding for MS students in Pharmacy. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Public Health Scholarship (MS) - 17',
  'Global Health Education Fund',
  'Türkiye',
  'MS',
  'Public Health',
  10000,
  'USD',
  '2027-01-21',
  'Sample medical funding for MS students in Public Health. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Public Health Scholarship (PhD) - 18',
  'Global Health Education Fund',
  'China',
  'PhD',
  'Public Health',
  12000,
  'USD',
  '2027-02-22',
  'Sample medical funding for PhD students in Public Health. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Biomedical Sciences Scholarship (BS) - 19',
  'Global Health Education Fund',
  'Malaysia',
  'BS',
  'Biomedical Sciences',
  15000,
  'USD',
  '2027-03-23',
  'Sample medical funding for BS students in Biomedical Sciences. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Biomedical Sciences Scholarship (MS) - 20',
  'Global Health Education Fund',
  'Italy',
  'MS',
  'Biomedical Sciences',
  18000,
  'USD',
  '2027-04-24',
  'Sample medical funding for MS students in Biomedical Sciences. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Electrical Engineering Scholarship (BS) - 21',
  'Global Engineering Education Fund',
  'United Kingdom',
  'BS',
  'Electrical Engineering',
  8000,
  'USD',
  '2027-05-05',
  'Sample engineering funding for BS students in Electrical Engineering. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Electrical Engineering Scholarship (MS) - 22',
  'Global Engineering Education Fund',
  'United States',
  'MS',
  'Electrical Engineering',
  10000,
  'USD',
  '2027-06-06',
  'Sample engineering funding for MS students in Electrical Engineering. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Mechanical Engineering Scholarship (MS) - 23',
  'Global Engineering Education Fund',
  'Germany',
  'MS',
  'Mechanical Engineering',
  12000,
  'USD',
  '2027-07-07',
  'Sample engineering funding for MS students in Mechanical Engineering. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Mechanical Engineering Scholarship (PhD) - 24',
  'Global Engineering Education Fund',
  'Japan',
  'PhD',
  'Mechanical Engineering',
  15000,
  'USD',
  '2027-08-08',
  'Sample engineering funding for PhD students in Mechanical Engineering. This is illustrative data created '
  'for the academic project, not a verified live offer. Confirm current availability, eligibility, award '
  'value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Civil Engineering Scholarship (BS) - 25',
  'Global Engineering Education Fund',
  'Australia',
  'BS',
  'Civil Engineering',
  18000,
  'USD',
  '2027-01-09',
  'Sample engineering funding for BS students in Civil Engineering. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Civil Engineering Scholarship (MS) - 26',
  'Global Engineering Education Fund',
  'Canada',
  'MS',
  'Civil Engineering',
  8000,
  'USD',
  '2027-02-10',
  'Sample engineering funding for MS students in Civil Engineering. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Environmental Engineering Scholarship (MS) - 27',
  'Global Engineering Education Fund',
  'Türkiye',
  'MS',
  'Environmental Engineering',
  10000,
  'USD',
  '2027-03-11',
  'Sample engineering funding for MS students in Environmental Engineering. This is illustrative data '
  'created for the academic project, not a verified live offer. Confirm current availability, eligibility, '
  'award value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Environmental Engineering Scholarship (PhD) - 28',
  'Global Engineering Education Fund',
  'China',
  'PhD',
  'Environmental Engineering',
  12000,
  'USD',
  '2027-04-12',
  'Sample engineering funding for PhD students in Environmental Engineering. This is illustrative data '
  'created for the academic project, not a verified live offer. Confirm current availability, eligibility, '
  'award value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Chemical Engineering Scholarship (BS) - 29',
  'Global Engineering Education Fund',
  'Malaysia',
  'BS',
  'Chemical Engineering',
  15000,
  'USD',
  '2027-05-13',
  'Sample engineering funding for BS students in Chemical Engineering. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Chemical Engineering Scholarship (MS) - 30',
  'Global Engineering Education Fund',
  'Italy',
  'MS',
  'Chemical Engineering',
  18000,
  'USD',
  '2027-06-14',
  'Sample engineering funding for MS students in Chemical Engineering. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Business Administration Scholarship (BS) - 31',
  'Global Business Education Fund',
  'United Kingdom',
  'BS',
  'Business Administration',
  8000,
  'USD',
  '2027-07-15',
  'Sample business funding for BS students in Business Administration. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Business Administration Scholarship (MS) - 32',
  'Global Business Education Fund',
  'United States',
  'MS',
  'Business Administration',
  10000,
  'USD',
  '2027-08-16',
  'Sample business funding for MS students in Business Administration. This is illustrative data created for '
  'the academic project, not a verified live offer. Confirm current availability, eligibility, award value '
  'and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Economics Scholarship (MS) - 33',
  'Global Business Education Fund',
  'Germany',
  'MS',
  'Economics',
  12000,
  'USD',
  '2027-01-17',
  'Sample business funding for MS students in Economics. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Economics Scholarship (PhD) - 34',
  'Global Business Education Fund',
  'Japan',
  'PhD',
  'Economics',
  15000,
  'USD',
  '2027-02-18',
  'Sample business funding for PhD students in Economics. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Finance Scholarship (BS) - 35',
  'Global Business Education Fund',
  'Australia',
  'BS',
  'Finance',
  18000,
  'USD',
  '2027-03-19',
  'Sample business funding for BS students in Finance. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Finance Scholarship (MS) - 36',
  'Global Business Education Fund',
  'Canada',
  'MS',
  'Finance',
  8000,
  'USD',
  '2027-04-20',
  'Sample business funding for MS students in Finance. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Accounting Scholarship (MS) - 37',
  'Global Business Education Fund',
  'Türkiye',
  'MS',
  'Accounting',
  10000,
  'USD',
  '2027-05-21',
  'Sample business funding for MS students in Accounting. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Accounting Scholarship (PhD) - 38',
  'Global Business Education Fund',
  'China',
  'PhD',
  'Accounting',
  12000,
  'USD',
  '2027-06-22',
  'Sample business funding for PhD students in Accounting. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Marketing Scholarship (BS) - 39',
  'Global Business Education Fund',
  'Malaysia',
  'BS',
  'Marketing',
  15000,
  'USD',
  '2027-07-23',
  'Sample business funding for BS students in Marketing. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Marketing Scholarship (MS) - 40',
  'Global Business Education Fund',
  'Italy',
  'MS',
  'Marketing',
  18000,
  'USD',
  '2027-08-24',
  'Sample business funding for MS students in Marketing. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Law Scholarship (BS) - 41',
  'Global Social Sciences Education Fund',
  'United Kingdom',
  'BS',
  'Law',
  8000,
  'USD',
  '2027-01-05',
  'Sample social sciences funding for BS students in Law. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Law Scholarship (MS) - 42',
  'Global Social Sciences Education Fund',
  'United States',
  'MS',
  'Law',
  10000,
  'USD',
  '2027-02-06',
  'Sample social sciences funding for MS students in Law. This is illustrative data created for the academic '
  'project, not a verified live offer. Confirm current availability, eligibility, award value and deadline '
  'with the provider.',
  'https://example.org/scholarships'),
 ('Education Scholarship (MS) - 43',
  'Global Social Sciences Education Fund',
  'Germany',
  'MS',
  'Education',
  12000,
  'USD',
  '2027-03-07',
  'Sample social sciences funding for MS students in Education. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Education Scholarship (PhD) - 44',
  'Global Social Sciences Education Fund',
  'Japan',
  'PhD',
  'Education',
  15000,
  'USD',
  '2027-04-08',
  'Sample social sciences funding for PhD students in Education. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Psychology Scholarship (BS) - 45',
  'Global Social Sciences Education Fund',
  'Australia',
  'BS',
  'Psychology',
  18000,
  'USD',
  '2027-05-09',
  'Sample social sciences funding for BS students in Psychology. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Psychology Scholarship (MS) - 46',
  'Global Social Sciences Education Fund',
  'Canada',
  'MS',
  'Psychology',
  8000,
  'USD',
  '2027-06-10',
  'Sample social sciences funding for MS students in Psychology. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Agriculture Scholarship (MS) - 47',
  'Global Social Sciences Education Fund',
  'Türkiye',
  'MS',
  'Agriculture',
  10000,
  'USD',
  '2027-07-11',
  'Sample social sciences funding for MS students in Agriculture. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Agriculture Scholarship (PhD) - 48',
  'Global Social Sciences Education Fund',
  'China',
  'PhD',
  'Agriculture',
  12000,
  'USD',
  '2027-08-12',
  'Sample social sciences funding for PhD students in Agriculture. This is illustrative data created for the '
  'academic project, not a verified live offer. Confirm current availability, eligibility, award value and '
  'deadline with the provider.',
  'https://example.org/scholarships'),
 ('Environmental Science Scholarship (BS) - 49',
  'Global Social Sciences Education Fund',
  'Malaysia',
  'BS',
  'Environmental Science',
  15000,
  'USD',
  '2027-01-13',
  'Sample social sciences funding for BS students in Environmental Science. This is illustrative data '
  'created for the academic project, not a verified live offer. Confirm current availability, eligibility, '
  'award value and deadline with the provider.',
  'https://example.org/scholarships'),
 ('Environmental Science Scholarship (MS) - 50',
  'Global Social Sciences Education Fund',
  'Italy',
  'MS',
  'Environmental Science',
  18000,
  'USD',
  '2027-02-14',
  'Sample social sciences funding for MS students in Environmental Science. This is illustrative data '
  'created for the academic project, not a verified live offer. Confirm current availability, eligibility, '
  'award value and deadline with the provider.',
  'https://example.org/scholarships')]

def normalize_degree(value):
    value = (value or "").strip().lower()
    aliases = {"bachelor": "BS", "bachelors": "BS", "bachelor's": "BS", "bachelor of science": "BS", "bachelor of arts": "BS", "undergraduate": "BS", "bs": "BS", "b.sc": "BS", "master": "MS", "masters": "MS", "master's": "MS", "master of science": "MS", "master of arts": "MS", "ms": "MS", "m.sc": "MS", "mphil": "MS", "phd": "PhD", "ph.d": "PhD", "doctorate": "PhD", "doctoral": "PhD"}
    return aliases.get(value, value.upper() if value in {"bs", "ms"} else value.title())

def split_values(value):
    return [part.strip() for part in (value or "").split(",") if part.strip()]

def related_fields(value):
    field = (value or "").strip().lower()
    groups = {
        "technology": ["Computer Science", "Information Technology", "Software Engineering", "Data Science", "Artificial Intelligence"],
        "medical": ["Medicine", "Nursing", "Pharmacy", "Public Health", "Biomedical Sciences"],
        "engineering": ["Electrical Engineering", "Mechanical Engineering", "Civil Engineering", "Environmental Engineering", "Chemical Engineering"],
        "business": ["Business Administration", "Economics", "Finance", "Accounting", "Marketing"],
        "social sciences": ["Law", "Education", "Psychology", "Agriculture", "Environmental Science"]
    }
    aliases = {
        "it": "technology", "computer": "technology", "computing": "technology", "computer science": "technology",
        "information technology": "technology", "software engineering": "technology", "data science": "technology", "artificial intelligence": "technology",
        "health": "medical", "health sciences": "medical", "medicine": "medical", "nursing": "medical", "pharmacy": "medical", "public health": "medical", "biomedical sciences": "medical",
        "business administration": "business", "management": "business", "economics": "business", "finance": "business", "accounting": "business", "marketing": "business",
        "law": "social sciences", "education": "social sciences", "psychology": "social sciences", "agriculture": "social sciences", "environmental science": "social sciences"
    }
    group = field if field in groups else aliases.get(field)
    if group:
        return groups[group]
    for group_name, fields in groups.items():
        if any(field == item.lower() for item in fields):
            return fields
    return [value.strip()] if value and value.strip() else []

def add_eligibility_rules(cur, scholarship_id, degrees, fields, min_cgpa=0, eligible_country="Any"):
    degrees = split_values(degrees) or ["Any"]
    fields = split_values(fields) or ["Any"]
    for degree in degrees:
        degree = "Any" if degree.lower() == "any" else normalize_degree(degree)
        for field in fields:
            field = "Any" if field.lower() == "any" else field.strip()
            cur.execute("""INSERT INTO eligibility_rules
                (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
                VALUES (%s,%s,%s,%s,%s)""",
                (scholarship_id, min_cgpa, eligible_country or "Any", degree, field))


def hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def get_connection():
    return mysql.connector.connect(database=DB_NAME, **DB_CONFIG)

def initialize_database():
    # Create database first, then connect to it.
    conn = mysql.connector.connect(**DB_CONFIG)
    cur = conn.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
    cur.close()
    conn.close()

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS students (
        student_id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password_hash CHAR(64) NOT NULL,
        phone VARCHAR(25),
        country VARCHAR(60) NOT NULL,
        education_level VARCHAR(50) NOT NULL,
        field_of_study VARCHAR(100) NOT NULL,
        cgpa DECIMAL(3,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS universities (
        university_id INT AUTO_INCREMENT PRIMARY KEY,
        university_name VARCHAR(150) NOT NULL,
        country VARCHAR(60) NOT NULL,
        website VARCHAR(255)
    ) ENGINE=InnoDB
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS scholarships (
        scholarship_id INT AUTO_INCREMENT PRIMARY KEY,
        university_id INT NULL,
        title VARCHAR(150) NOT NULL,
        provider VARCHAR(120) NOT NULL,
        country VARCHAR(60) NOT NULL,
        degree_level VARCHAR(50) NOT NULL,
        field_of_study VARCHAR(100) NOT NULL,
        amount DECIMAL(12,2) DEFAULT 0,
        currency VARCHAR(10) DEFAULT 'USD',
        deadline DATE NOT NULL,
        description TEXT,
        application_url VARCHAR(255),
        status ENUM('Open','Closed') DEFAULT 'Open',
        CONSTRAINT fk_scholarship_university
          FOREIGN KEY (university_id) REFERENCES universities(university_id)
          ON DELETE SET NULL
    ) ENGINE=InnoDB
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS eligibility_rules (
        eligibility_id INT AUTO_INCREMENT PRIMARY KEY,
        scholarship_id INT NOT NULL,
        min_cgpa DECIMAL(3,2) DEFAULT 0,
        eligible_country VARCHAR(60) DEFAULT 'Any',
        required_degree VARCHAR(50) DEFAULT 'Any',
        required_field VARCHAR(100) DEFAULT 'Any',
        age_limit INT NULL,
        CONSTRAINT fk_rule_scholarship
          FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id)
          ON DELETE CASCADE
    ) ENGINE=InnoDB
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS applications (
        application_id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        scholarship_id INT NOT NULL,
        application_date DATE NOT NULL,
        application_status ENUM('Pending','Under Review','Approved','Rejected')
          DEFAULT 'Pending',
        remarks TEXT,
        UNIQUE KEY uq_student_scholarship (student_id, scholarship_id),
        CONSTRAINT fk_application_student
          FOREIGN KEY (student_id) REFERENCES students(student_id)
          ON DELETE CASCADE,
        CONSTRAINT fk_application_scholarship
          FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id)
          ON DELETE CASCADE
    ) ENGINE=InnoDB
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS admins (
        admin_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password_hash CHAR(64) NOT NULL
    ) ENGINE=InnoDB
    """)

    # Create a demo admin only if no admin exists.
    cur.execute("SELECT COUNT(*) FROM admins")
    if cur.fetchone()[0] == 0:
        cur.execute(
            "INSERT INTO admins (username, password_hash) VALUES (%s, %s)",
            ("admin", hash_password("Admin@123"))
        )

    # Seed 50 clearly labelled demonstration scholarships.
    # INSERT IGNORE-style title checks make startup safe and avoid duplicates.
    for title, provider, country, degree, field, amount, currency, deadline, description, url in SAMPLE_SCHOLARSHIPS:
        cur.execute("SELECT scholarship_id FROM scholarships WHERE title=%s", (title,))
        existing = cur.fetchone()
        if existing:
            scholarship_id = existing[0]
        else:
            cur.execute("""INSERT INTO scholarships
                (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
                VALUES (NULL,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'Open')""",
                (title, provider, country, degree, field, amount, currency, deadline, description, url))
            scholarship_id = cur.lastrowid
        cur.execute("SELECT COUNT(*) FROM eligibility_rules WHERE scholarship_id=%s", (scholarship_id,))
        if cur.fetchone()[0] == 0:
            add_eligibility_rules(cur, scholarship_id, degree, field, 2.50, "Any")

    # Ensure legacy scholarship records also have at least one eligibility rule.
    cur.execute("""SELECT s.scholarship_id,s.degree_level,s.field_of_study
                   FROM scholarships s LEFT JOIN eligibility_rules er
                   ON s.scholarship_id=er.scholarship_id
                   WHERE er.eligibility_id IS NULL""")
    for sid, degree, field in cur.fetchall():
        add_eligibility_rules(cur, sid, degree, field, 0, "Any")

    # Normalize common legacy degree labels so older records still match BS/MS/PhD profiles.
    cur.execute("UPDATE eligibility_rules SET required_degree='BS' WHERE LOWER(required_degree) IN ('bachelor','bachelors','bachelor''s','undergraduate')")
    cur.execute("UPDATE eligibility_rules SET required_degree='MS' WHERE LOWER(required_degree) IN ('master','masters','master''s','mphil')")
    cur.execute("UPDATE eligibility_rules SET required_degree='PhD' WHERE LOWER(required_degree) IN ('ph.d','doctorate','doctoral')")

    # View for the DBMS demonstration.
    cur.execute("DROP VIEW IF EXISTS available_scholarships")
    cur.execute("""
        CREATE VIEW available_scholarships AS
        SELECT s.scholarship_id, s.title, u.university_name,
               s.provider, s.country, s.degree_level, s.field_of_study,
               s.amount, s.currency, s.deadline, s.status
        FROM scholarships s
        LEFT JOIN universities u ON s.university_id = u.university_id
        WHERE s.status = 'Open'
    """)

    # Trigger: set today's date if application_date is NULL.
    cur.execute("DROP TRIGGER IF EXISTS set_application_date")
    cur.execute("""
        CREATE TRIGGER set_application_date
        BEFORE INSERT ON applications
        FOR EACH ROW
        BEGIN
            IF NEW.application_date IS NULL THEN
                SET NEW.application_date = CURDATE();
            END IF;
        END
    """)

    conn.commit()
    cur.close()
    conn.close()

class ScholarshipApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Scholarship Finder System")
        self.root.geometry("1100x700")
        self.root.minsize(900, 600)
        self.root.configure(bg="#f3f6fb")
        self.current_student = None
        self.current_admin = None
        self.show_welcome()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def heading(self, parent, title, subtitle=None):
        tk.Label(parent, text=title, font=("Arial", 23, "bold"),
                 bg="#17365d", fg="white", pady=17).pack(fill="x")
        if subtitle:
            tk.Label(parent, text=subtitle, font=("Arial", 10),
                     bg="#f3f6fb", fg="#425466", pady=10).pack()

    def make_button(self, parent, text, command, color="#1f5f99"):
        return tk.Button(parent, text=text, command=command,
                         bg=color, fg="white", activebackground=color,
                         activeforeground="white", relief="flat",
                         font=("Arial", 10, "bold"), padx=13, pady=8,
                         cursor="hand2")

    def show_welcome(self):
        self.clear()
        self.heading(self.root, "SCHOLARSHIP FINDER SYSTEM",
                     "Find opportunities. Check eligibility. Manage applications.")
        panel = tk.Frame(self.root, bg="white", padx=45, pady=35,
                         highlightbackground="#d8e1ed", highlightthickness=1)
        panel.pack(pady=55)
        tk.Label(panel, text="Welcome!", font=("Arial", 22, "bold"),
                 bg="white", fg="#17365d").pack(pady=(0, 8))
        tk.Label(panel, text="Please choose how you want to continue.",
                 font=("Arial", 11), bg="white", fg="#526477").pack(pady=(0, 25))
        self.make_button(panel, "Student Login", self.show_student_login).pack(fill="x", pady=6)
        self.make_button(panel, "Student Registration", self.show_register, "#287a61").pack(fill="x", pady=6)
        self.make_button(panel, "Admin Login", self.show_admin_login, "#6b568f").pack(fill="x", pady=6)
        tk.Label(self.root, text="Demo admin: username admin | password Admin@123",
                 bg="#f3f6fb", fg="#6b7280", font=("Arial", 9)).pack()

    def form_window(self, title, fields, submit_text, submit_command, back_command):
        self.clear()
        self.heading(self.root, title)
        card = tk.Frame(self.root, bg="white", padx=35, pady=25)
        card.pack(pady=18)
        entries = {}
        for label, key, secret in fields:
            tk.Label(card, text=label, bg="white", fg="#26384a",
                     font=("Arial", 10, "bold")).pack(anchor="w", pady=(7, 2))
            entry = tk.Entry(card, width=42, show="*" if secret else "")
            entry.pack(ipady=6)
            entries[key] = entry
        buttons = tk.Frame(card, bg="white")
        buttons.pack(pady=18)
        self.make_button(buttons, submit_text,
                         lambda: submit_command(entries)).pack(side="left", padx=5)
        self.make_button(buttons, "Back", back_command, "#687787").pack(side="left", padx=5)
        return entries

    def show_register(self):
        fields = [
            ("Full name", "name", False), ("Email", "email", False),
            ("Password", "password", True), ("Phone", "phone", False),
            ("Country (e.g. Pakistan)", "country", False),
            ("Education level (BS/MS/PhD)", "degree", False),
            ("Field of study", "field", False), ("CGPA (0.00 to 4.00)", "cgpa", False)
        ]
        self.form_window("STUDENT REGISTRATION", fields, "Create Account",
                         self.register_student, self.show_welcome)

    def register_student(self, e):
        vals = {k: v.get().strip() for k, v in e.items()}
        if not all(vals.values()):
            messagebox.showerror("Missing information", "Please fill in all fields.")
            return
        try:
            cgpa = float(vals["cgpa"])
            if not 0 <= cgpa <= 4:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid CGPA", "Enter a CGPA between 0 and 4.")
            return
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO students
                (full_name,email,password_hash,phone,country,education_level,field_of_study,cgpa)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
            """, (vals["name"], vals["email"], hash_password(vals["password"]),
                  vals["phone"], vals["country"], normalize_degree(vals["degree"]), vals["field"], cgpa))
            conn.commit()
            cur.close()
            conn.close()
            messagebox.showinfo("Success", "Account created. You can now log in.")
            self.show_student_login()
        except Error as ex:
            messagebox.showerror("Database error", f"Could not register:\n{ex}")

    def show_student_login(self):
        fields = [("Email", "email", False), ("Password", "password", True)]
        self.form_window("STUDENT LOGIN", fields, "Login",
                         self.student_login, self.show_welcome)

    def student_login(self, e):
        email, password = e["email"].get().strip(), e["password"].get()
        try:
            conn = get_connection()
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT * FROM students WHERE email=%s AND password_hash=%s",
                        (email, hash_password(password)))
            student = cur.fetchone()
            cur.close()
            conn.close()
            if not student:
                messagebox.showerror("Login failed", "Incorrect email or password.")
                return
            self.current_student = student
            self.show_student_dashboard()
        except Error as ex:
            messagebox.showerror("Database error", str(ex))

    def show_admin_login(self):
        fields = [("Username", "username", False), ("Password", "password", True)]
        self.form_window("ADMIN LOGIN", fields, "Login",
                         self.admin_login, self.show_welcome)

    def admin_login(self, e):
        try:
            conn = get_connection()
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT * FROM admins WHERE username=%s AND password_hash=%s",
                        (e["username"].get().strip(), hash_password(e["password"].get())))
            admin = cur.fetchone()
            cur.close()
            conn.close()
            if not admin:
                messagebox.showerror("Login failed", "Incorrect admin username or password.")
                return
            self.current_admin = admin
            self.show_admin_dashboard()
        except Error as ex:
            messagebox.showerror("Database error", str(ex))

    def show_student_dashboard(self):
        self.clear()
        s = self.current_student
        self.heading(self.root, f"Welcome, {s['full_name']}",
                     f"Profile: {s['education_level']} | {s['field_of_study']} | CGPA: {s['cgpa']}")
        nav = tk.Frame(self.root, bg="#e5edf6", pady=10)
        nav.pack(fill="x")
        for label, cmd in [
            ("Search Scholarships", self.show_scholarships),
            ("My Applications", self.show_my_applications),
            ("Logout", self.logout)
        ]:
            self.make_button(nav, label, cmd).pack(side="left", padx=8)
        body = tk.Frame(self.root, bg="#f3f6fb")
        body.pack(fill="both", expand=True, padx=30, pady=30)
        tk.Label(body, text="Your scholarship journey starts here.",
                 font=("Arial", 19, "bold"), bg="#f3f6fb", fg="#17365d").pack(pady=20)
        tk.Label(body, text="Search scholarships, review their requirements, and submit applications.",
                 font=("Arial", 12), bg="#f3f6fb", fg="#425466").pack()

    def show_scholarships(self):
        self.clear()
        self.heading(self.root, "AVAILABLE SCHOLARSHIPS",
                     "Scholarships are matched to your degree, field of study, country and CGPA.")
        top = tk.Frame(self.root, bg="#f3f6fb", pady=8)
        top.pack(fill="x", padx=18)
        country = tk.Entry(top, width=18)
        degree = tk.Entry(top, width=18)
        field = tk.Entry(top, width=18)
        for label, ent in [("Country", country), ("Degree", degree), ("Field", field)]:
            tk.Label(top, text=label, bg="#f3f6fb").pack(side="left", padx=(5, 2))
            ent.pack(side="left", padx=3, ipady=4)
        cols = ("id", "title", "provider", "country", "degree", "field", "amount", "deadline")
        tree = ttk.Treeview(self.root, columns=cols, show="headings", height=16)
        labels = ["ID", "Scholarship", "Provider", "Country", "Degree", "Field", "Amount", "Deadline"]
        widths = [45, 190, 175, 105, 85, 135, 95, 100]
        for c, lab, width in zip(cols, labels, widths):
            tree.heading(c, text=lab)
            tree.column(c, width=width, anchor="center")
        tree.pack(fill="both", expand=True, padx=18, pady=8)

        def load():
            for item in tree.get_children():
                tree.delete(item)
            try:
                conn = get_connection()
                cur = conn.cursor()
                sql = """
                    SELECT s.scholarship_id, s.title, s.provider,
                           s.country, s.degree_level, s.field_of_study,
                           CONCAT(s.currency,' ',s.amount), s.deadline
                    FROM scholarships s
                    WHERE s.status='Open' AND s.deadline >= CURDATE()
                      AND s.country LIKE %s AND s.degree_level LIKE %s
                      AND s.field_of_study LIKE %s
                      AND EXISTS (
                        SELECT 1 FROM eligibility_rules er
                        WHERE er.scholarship_id=s.scholarship_id
                          AND (LOWER(er.eligible_country)='any' OR LOWER(er.eligible_country)=LOWER(%s))
                          AND (LOWER(er.required_degree)='any' OR LOWER(er.required_degree)=LOWER(%s))
                          AND (LOWER(er.required_field)='any' OR LOWER(er.required_field) IN ({field_placeholders}))
                          AND COALESCE(er.min_cgpa,0) <= %s
                      )
                    ORDER BY s.deadline
                """
                student = self.current_student
                matching_fields = related_fields(student["field_of_study"]) or [student["field_of_study"]]
                field_placeholders = ",".join(["%s"] * len(matching_fields))
                sql = sql.format(field_placeholders=field_placeholders)
                cur.execute(sql, (f"%{country.get().strip()}%",
                                  f"%{degree.get().strip()}%",
                                  f"%{field.get().strip()}%",
                                  student["country"], normalize_degree(student["education_level"]),
                                  *[value.lower() for value in matching_fields], float(student["cgpa"])))
                for row in cur.fetchall():
                    tree.insert("", "end", values=row)
                cur.close()
                conn.close()
            except Error as ex:
                messagebox.showerror("Database error", str(ex))

        def apply_selected():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Select scholarship", "Please select a scholarship first.")
                return
            scholarship_id = tree.item(selected[0], "values")[0]
            try:
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("""
                    INSERT INTO applications
                    (student_id, scholarship_id, application_date)
                    VALUES (%s,%s,%s)
                """, (self.current_student["student_id"], scholarship_id, date.today()))
                conn.commit()
                cur.close()
                conn.close()
                messagebox.showinfo("Application submitted", "Your application was submitted.")
            except mysql.connector.IntegrityError:
                messagebox.showwarning("Already applied", "You have already applied for this scholarship.")
            except Error as ex:
                messagebox.showerror("Database error", str(ex))

        buttons = tk.Frame(self.root, bg="#f3f6fb", pady=8)
        buttons.pack()
        self.make_button(buttons, "Search / Refresh", load).pack(side="left", padx=5)
        self.make_button(buttons, "Apply for Selected", apply_selected, "#287a61").pack(side="left", padx=5)
        self.make_button(buttons, "Back to Dashboard", self.show_student_dashboard, "#687787").pack(side="left", padx=5)
        load()

    def show_my_applications(self):
        self.clear()
        self.heading(self.root, "MY APPLICATIONS", "Track the status of your scholarship applications.")
        cols = ("id", "title", "date", "status", "remarks")
        tree = ttk.Treeview(self.root, columns=cols, show="headings", height=18)
        for c, lab, width in zip(cols, ["ID", "Scholarship", "Applied On", "Status", "Remarks"],
                                  [65, 300, 150, 150, 300]):
            tree.heading(c, text=lab)
            tree.column(c, width=width, anchor="center")
        tree.pack(fill="both", expand=True, padx=25, pady=20)
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT a.application_id, s.title, a.application_date,
                       a.application_status, COALESCE(a.remarks,'')
                FROM applications a
                JOIN scholarships s ON a.scholarship_id=s.scholarship_id
                WHERE a.student_id=%s ORDER BY a.application_date DESC
            """, (self.current_student["student_id"],))
            for row in cur.fetchall():
                tree.insert("", "end", values=row)
            cur.close()
            conn.close()
        except Error as ex:
            messagebox.showerror("Database error", str(ex))
        self.make_button(self.root, "Back to Dashboard", self.show_student_dashboard, "#687787").pack(pady=10)

    def show_admin_dashboard(self):
        self.clear()
        self.heading(self.root, "ADMIN DASHBOARD", "Manage scholarships, students and applications.")
        nav = tk.Frame(self.root, bg="#e5edf6", pady=10)
        nav.pack(fill="x")
        for label, cmd in [
            ("Manage Scholarships", self.show_manage_scholarships),
            ("View Students", self.show_students_admin),
            ("Manage Applications", self.show_manage_applications),
            ("Logout", self.logout)
        ]:
            self.make_button(nav, label, cmd).pack(side="left", padx=8)
        tk.Label(self.root, text="Administration Panel",
                 font=("Arial", 22, "bold"), bg="#f3f6fb", fg="#17365d").pack(pady=70)
        self.show_admin_counts()

    def show_admin_counts(self):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM students")
            students = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM scholarships")
            scholarships = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM applications")
            applications = cur.fetchone()[0]
            cur.close()
            conn.close()
            tk.Label(self.root,
                     text=f"Registered Students: {students}     Scholarships: {scholarships}     Applications: {applications}",
                     font=("Arial", 13), bg="#f3f6fb", fg="#425466").pack(pady=10)
        except Error as ex:
            messagebox.showerror("Database error", str(ex))

    def show_manage_scholarships(self):
        self.clear()
        self.heading(self.root, "MANAGE SCHOLARSHIPS", "Add, update or delete scholarship records.")
        form = tk.Frame(self.root, bg="white", padx=12, pady=10)
        form.pack(fill="x", padx=15, pady=10)
        fields = [
            ("Title", "title"), ("Provider", "provider"), ("Country", "country"),
            ("Eligible Degrees (comma-separated)", "degree"), ("Eligible Fields (comma-separated)", "field"),
            ("Amount", "amount"), ("Currency", "currency"),
            ("Deadline YYYY-MM-DD", "deadline"), ("University ID (optional)", "university_id"),
            ("Minimum CGPA", "min_cgpa"), ("Eligible Student Country (or Any)", "eligible_country"),
            ("Description", "description"), ("Application URL", "url")
        ]
        entries = {}
        for i, (label, key) in enumerate(fields):
            r, c = divmod(i, 4)
            cell = tk.Frame(form, bg="white")
            cell.grid(row=r, column=c, padx=5, pady=4, sticky="w")
            tk.Label(cell, text=label, bg="white", font=("Arial", 8, "bold")).pack(anchor="w")
            ent = tk.Entry(cell, width=23)
            ent.pack()
            entries[key] = ent

        cols = ("id", "title", "country", "degree", "field", "deadline", "status")
        tree = ttk.Treeview(self.root, columns=cols, show="headings", height=12)
        for c, lab, width in zip(cols, ["ID", "Title", "Country", "Degree", "Field", "Deadline", "Status"],
                                  [45, 240, 130, 100, 150, 110, 80]):
            tree.heading(c, text=lab)
            tree.column(c, width=width, anchor="center")
        tree.pack(fill="both", expand=True, padx=15, pady=8)

        def load():
            for item in tree.get_children():
                tree.delete(item)
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT scholarship_id,title,country,degree_level,field_of_study,deadline,status FROM scholarships")
            for row in cur.fetchall():
                tree.insert("", "end", values=row)
            cur.close()
            conn.close()

        def clear_form():
            for ent in entries.values():
                ent.delete(0, "end")

        def selected_id():
            selected = tree.selection()
            return tree.item(selected[0], "values")[0] if selected else None

        def fill_form(_event=None):
            selected = selected_id()
            if not selected:
                return
            conn = get_connection()
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT * FROM scholarships WHERE scholarship_id=%s", (selected,))
            row = cur.fetchone()
            cur.execute("SELECT * FROM eligibility_rules WHERE scholarship_id=%s ORDER BY eligibility_id", (selected,))
            rules = cur.fetchall()
            cur.close()
            conn.close()
            mapping = {"title":"title","provider":"provider","country":"country",
                       "degree":"degree_level","field":"field_of_study","amount":"amount",
                       "currency":"currency","deadline":"deadline","university_id":"university_id",
                       "description":"description","url":"application_url"}
            for key, col in mapping.items():
                entries[key].delete(0, "end")
                if row[col] is not None:
                    entries[key].insert(0, str(row[col]))
            entries["degree"].delete(0, "end")
            entries["field"].delete(0, "end")
            entries["min_cgpa"].delete(0, "end")
            entries["eligible_country"].delete(0, "end")
            if rules:
                entries["degree"].insert(0, ",".join(dict.fromkeys(r["required_degree"] for r in rules)))
                entries["field"].insert(0, ",".join(dict.fromkeys(r["required_field"] for r in rules)))
                entries["min_cgpa"].insert(0, str(min(float(r["min_cgpa"] or 0) for r in rules)))
                entries["eligible_country"].insert(0, rules[0]["eligible_country"] or "Any")
            else:
                entries["min_cgpa"].insert(0, "0")
                entries["eligible_country"].insert(0, "Any")
            conn.close()

        def save(update=False):
            required = ["title","provider","country","degree","field","amount","currency","deadline","min_cgpa"]
            if any(not entries[k].get().strip() for k in required):
                messagebox.showerror("Missing fields", "Please fill title, provider, country, degree, field, amount, currency and deadline.")
                return
            try:
                amount = float(entries["amount"].get())
                min_cgpa = float(entries["min_cgpa"].get())
                if not 0 <= min_cgpa <= 4:
                    raise ValueError
                uid_text = entries["university_id"].get().strip()
                uid = int(uid_text) if uid_text else None
                values = (uid, entries["title"].get().strip(), entries["provider"].get().strip(),
                          entries["country"].get().strip(), entries["degree"].get().strip(),
                          entries["field"].get().strip(), amount, entries["currency"].get().strip(),
                          entries["deadline"].get().strip(), entries["description"].get().strip(),
                          entries["url"].get().strip())
                conn = get_connection()
                cur = conn.cursor()
                if update:
                    sid = selected_id()
                    if not sid:
                        messagebox.showwarning("Select record", "Select a scholarship to update.")
                        cur.close(); conn.close()
                        return
                    cur.execute("""
                        UPDATE scholarships SET university_id=%s,title=%s,provider=%s,country=%s,
                        degree_level=%s,field_of_study=%s,amount=%s,currency=%s,deadline=%s,
                        description=%s,application_url=%s WHERE scholarship_id=%s
                    """, values + (sid,))
                    cur.execute("DELETE FROM eligibility_rules WHERE scholarship_id=%s", (sid,))
                    add_eligibility_rules(cur, sid, entries["degree"].get(), entries["field"].get(),
                                          min_cgpa, entries["eligible_country"].get().strip() or "Any")
                else:
                    cur.execute("""
                        INSERT INTO scholarships
                        (university_id,title,provider,country,degree_level,field_of_study,
                         amount,currency,deadline,description,application_url)
                        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    """, values)
                    add_eligibility_rules(cur, cur.lastrowid, entries["degree"].get(),
                                          entries["field"].get(), min_cgpa,
                                          entries["eligible_country"].get().strip() or "Any")
                conn.commit()
                cur.close(); conn.close()
                messagebox.showinfo("Success", "Scholarship record saved.")
                load(); clear_form()
            except ValueError:
                messagebox.showerror("Invalid value", "Amount and minimum CGPA must be numeric (CGPA: 0 to 4); University ID must be an integer.")
            except Error as ex:
                messagebox.showerror("Database error", str(ex))

        def delete():
            sid = selected_id()
            if not sid:
                messagebox.showwarning("Select record", "Select a scholarship to delete.")
                return
            if not messagebox.askyesno("Confirm delete", "Delete this scholarship and its related applications/rules?"):
                return
            try:
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("DELETE FROM scholarships WHERE scholarship_id=%s", (sid,))
                conn.commit()
                cur.close(); conn.close()
                load(); clear_form()
            except Error as ex:
                messagebox.showerror("Database error", str(ex))

        tree.bind("<<TreeviewSelect>>", fill_form)
        buttons = tk.Frame(self.root, bg="#f3f6fb")
        buttons.pack(pady=8)
        self.make_button(buttons, "Add", lambda: save(False), "#287a61").pack(side="left", padx=4)
        self.make_button(buttons, "Update Selected", lambda: save(True)).pack(side="left", padx=4)
        self.make_button(buttons, "Delete Selected", delete, "#a33b3b").pack(side="left", padx=4)
        self.make_button(buttons, "Clear Form", clear_form, "#687787").pack(side="left", padx=4)
        self.make_button(buttons, "Back", self.show_admin_dashboard, "#687787").pack(side="left", padx=4)
        load()

    def show_students_admin(self):
        self.clear()
        self.heading(self.root, "REGISTERED STUDENTS")
        cols = ("id","name","email","country","degree","field","cgpa")
        tree = ttk.Treeview(self.root, columns=cols, show="headings")
        for c, lab, width in zip(cols, ["ID","Name","Email","Country","Degree","Field","CGPA"],
                                  [50,160,200,110,100,180,70]):
            tree.heading(c,text=lab); tree.column(c,width=width,anchor="center")
        tree.pack(fill="both",expand=True,padx=20,pady=20)
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""SELECT student_id,full_name,email,country,education_level,
                       field_of_study,cgpa FROM students ORDER BY student_id DESC""")
        for row in cur.fetchall():
            tree.insert("","end",values=row)
        cur.close(); conn.close()
        self.make_button(self.root,"Back",self.show_admin_dashboard,"#687787").pack(pady=10)

    def show_manage_applications(self):
        self.clear()
        self.heading(self.root, "MANAGE APPLICATIONS", "Select an application and update its status.")
        cols = ("id","student","scholarship","date","status")
        tree = ttk.Treeview(self.root, columns=cols, show="headings", height=18)
        for c, lab, width in zip(cols, ["ID","Student","Scholarship","Date","Status"],
                                  [60,200,350,130,140]):
            tree.heading(c,text=lab); tree.column(c,width=width,anchor="center")
        tree.pack(fill="both",expand=True,padx=20,pady=15)
        def load():
            for item in tree.get_children(): tree.delete(item)
            conn=get_connection(); cur=conn.cursor()
            cur.execute("""SELECT a.application_id,st.full_name,s.title,a.application_date,a.application_status
                           FROM applications a JOIN students st ON a.student_id=st.student_id
                           JOIN scholarships s ON a.scholarship_id=s.scholarship_id
                           ORDER BY a.application_date DESC""")
            for row in cur.fetchall(): tree.insert("","end",values=row)
            cur.close(); conn.close()
        def update_status():
            selected=tree.selection()
            if not selected:
                messagebox.showwarning("Select application","Select an application first."); return
            aid=tree.item(selected[0],"values")[0]
            status=status_box.get()
            if not status:
                messagebox.showwarning("Choose status","Choose a status."); return
            conn=get_connection(); cur=conn.cursor()
            cur.execute("UPDATE applications SET application_status=%s WHERE application_id=%s",(status,aid))
            conn.commit(); cur.close(); conn.close()
            load(); messagebox.showinfo("Updated","Application status updated.")
        bar=tk.Frame(self.root,bg="#f3f6fb"); bar.pack(pady=8)
        status_box=ttk.Combobox(bar,values=["Pending","Under Review","Approved","Rejected"],state="readonly",width=18)
        status_box.set("Pending"); status_box.pack(side="left",padx=5)
        self.make_button(bar,"Update Selected Status",update_status).pack(side="left",padx=5)
        self.make_button(bar,"Refresh",load,"#687787").pack(side="left",padx=5)
        self.make_button(bar,"Back",self.show_admin_dashboard,"#687787").pack(side="left",padx=5)
        load()

    def logout(self):
        self.current_student = None
        self.current_admin = None
        self.show_welcome()

if __name__ == "__main__":
    try:
        initialize_database()
        root = tk.Tk()
        app = ScholarshipApp(root)
        root.mainloop()
    except Error as ex:
        temp = tk.Tk()
        temp.withdraw()
        messagebox.showerror(
            "Database connection error",
            "Could not connect to MySQL.\n\n"
            "1. Start MySQL in XAMPP.\n"
            "2. Check DB_CONFIG in main.py (default XAMPP user root, blank password).\n"
            "3. Make sure MySQL uses port 3306.\n\n"
            f"Details: {ex}"
        )
        temp.destroy()
