-- Scholarship Finder System: MySQL / MariaDB schema and 50 sample records
-- Run this in MySQL Workbench after starting MySQL in XAMPP.
-- Existing tables and records are retained; sample records are inserted only when missing.

CREATE DATABASE IF NOT EXISTS scholarship_finder;
USE scholarship_finder;

CREATE TABLE IF NOT EXISTS students (
 student_id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(100) NOT NULL,
 email VARCHAR(100) NOT NULL UNIQUE,
 password_hash CHAR(64) NOT NULL,
 phone VARCHAR(25),
 country VARCHAR(60) NOT NULL,
 education_level VARCHAR(50) NOT NULL,
 field_of_study VARCHAR(100) NOT NULL,
 cgpa DECIMAL(3,2) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS universities (
 university_id INT AUTO_INCREMENT PRIMARY KEY,
 university_name VARCHAR(150) NOT NULL,
 country VARCHAR(60) NOT NULL,
 website VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS scholarships (
 scholarship_id INT AUTO_INCREMENT PRIMARY KEY,
 university_id INT NULL,
 title VARCHAR(150) NOT NULL,
 provider VARCHAR(120) NOT NULL,
 country VARCHAR(60) NOT NULL,
 degree_level VARCHAR(50) NOT NULL,
 field_of_study VARCHAR(100) NOT NULL,
 amount DECIMAL(12,2) DEFAULT 0,
 currency VARCHAR(10) DEFAULT 'USD',
 deadline DATE NOT NULL,
 description TEXT,
 application_url VARCHAR(255),
 status ENUM('Open','Closed') DEFAULT 'Open',
 FOREIGN KEY (university_id) REFERENCES universities(university_id)
 ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS eligibility_rules (
 eligibility_id INT AUTO_INCREMENT PRIMARY KEY,
 scholarship_id INT NOT NULL,
 min_cgpa DECIMAL(3,2) DEFAULT 0,
 eligible_country VARCHAR(60) DEFAULT 'Any',
 required_degree VARCHAR(50) DEFAULT 'Any',
 required_field VARCHAR(100) DEFAULT 'Any',
 age_limit INT,
 FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id)
 ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS applications (
 application_id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 scholarship_id INT NOT NULL,
 application_date DATE NOT NULL,
 application_status ENUM('Pending','Under Review','Approved','Rejected') DEFAULT 'Pending',
 remarks TEXT,
 UNIQUE KEY uq_student_scholarship (student_id, scholarship_id),
 FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
 FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS admins (
 admin_id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 password_hash CHAR(64) NOT NULL
);

-- 50 preloaded demonstration scholarship records.
-- These are illustrative academic project records, not verified live offers.
-- Re-running this section does not create duplicate scholarship titles or rules.
INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Computer Science Scholarship (BS) - 01','Global Technology Education Fund','United Kingdom','BS','Computer Science',8000,'USD','2027-01-05','Sample technology funding for BS students in Computer Science. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Computer Science Scholarship (BS) - 01');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Computer Science' FROM scholarships s
WHERE s.title='Computer Science Scholarship (BS) - 01' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Computer Science Scholarship (MS) - 02','Global Technology Education Fund','United States','MS','Computer Science',10000,'USD','2027-02-06','Sample technology funding for MS students in Computer Science. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Computer Science Scholarship (MS) - 02');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Computer Science' FROM scholarships s
WHERE s.title='Computer Science Scholarship (MS) - 02' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Information Technology Scholarship (MS) - 03','Global Technology Education Fund','Germany','MS','Information Technology',12000,'USD','2027-03-07','Sample technology funding for MS students in Information Technology. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Information Technology Scholarship (MS) - 03');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Information Technology' FROM scholarships s
WHERE s.title='Information Technology Scholarship (MS) - 03' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Information Technology Scholarship (PhD) - 04','Global Technology Education Fund','Japan','PhD','Information Technology',15000,'USD','2027-04-08','Sample technology funding for PhD students in Information Technology. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Information Technology Scholarship (PhD) - 04');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Information Technology' FROM scholarships s
WHERE s.title='Information Technology Scholarship (PhD) - 04' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Software Engineering Scholarship (BS) - 05','Global Technology Education Fund','Australia','BS','Software Engineering',18000,'USD','2027-05-09','Sample technology funding for BS students in Software Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Software Engineering Scholarship (BS) - 05');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Software Engineering' FROM scholarships s
WHERE s.title='Software Engineering Scholarship (BS) - 05' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Software Engineering Scholarship (MS) - 06','Global Technology Education Fund','Canada','MS','Software Engineering',8000,'USD','2027-06-10','Sample technology funding for MS students in Software Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Software Engineering Scholarship (MS) - 06');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Software Engineering' FROM scholarships s
WHERE s.title='Software Engineering Scholarship (MS) - 06' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Data Science Scholarship (MS) - 07','Global Technology Education Fund','Türkiye','MS','Data Science',10000,'USD','2027-07-11','Sample technology funding for MS students in Data Science. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Data Science Scholarship (MS) - 07');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Data Science' FROM scholarships s
WHERE s.title='Data Science Scholarship (MS) - 07' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Data Science Scholarship (PhD) - 08','Global Technology Education Fund','China','PhD','Data Science',12000,'USD','2027-08-12','Sample technology funding for PhD students in Data Science. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Data Science Scholarship (PhD) - 08');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Data Science' FROM scholarships s
WHERE s.title='Data Science Scholarship (PhD) - 08' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Artificial Intelligence Scholarship (BS) - 09','Global Technology Education Fund','Malaysia','BS','Artificial Intelligence',15000,'USD','2027-01-13','Sample technology funding for BS students in Artificial Intelligence. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Artificial Intelligence Scholarship (BS) - 09');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Artificial Intelligence' FROM scholarships s
WHERE s.title='Artificial Intelligence Scholarship (BS) - 09' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Artificial Intelligence Scholarship (MS) - 10','Global Technology Education Fund','Italy','MS','Artificial Intelligence',18000,'USD','2027-02-14','Sample technology funding for MS students in Artificial Intelligence. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Artificial Intelligence Scholarship (MS) - 10');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Artificial Intelligence' FROM scholarships s
WHERE s.title='Artificial Intelligence Scholarship (MS) - 10' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Medicine Scholarship (BS) - 11','Global Health Education Fund','United Kingdom','BS','Medicine',8000,'USD','2027-03-15','Sample medical funding for BS students in Medicine. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Medicine Scholarship (BS) - 11');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Medicine' FROM scholarships s
WHERE s.title='Medicine Scholarship (BS) - 11' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Medicine Scholarship (MS) - 12','Global Health Education Fund','United States','MS','Medicine',10000,'USD','2027-04-16','Sample medical funding for MS students in Medicine. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Medicine Scholarship (MS) - 12');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Medicine' FROM scholarships s
WHERE s.title='Medicine Scholarship (MS) - 12' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Nursing Scholarship (MS) - 13','Global Health Education Fund','Germany','MS','Nursing',12000,'USD','2027-05-17','Sample medical funding for MS students in Nursing. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Nursing Scholarship (MS) - 13');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Nursing' FROM scholarships s
WHERE s.title='Nursing Scholarship (MS) - 13' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Nursing Scholarship (PhD) - 14','Global Health Education Fund','Japan','PhD','Nursing',15000,'USD','2027-06-18','Sample medical funding for PhD students in Nursing. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Nursing Scholarship (PhD) - 14');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Nursing' FROM scholarships s
WHERE s.title='Nursing Scholarship (PhD) - 14' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Pharmacy Scholarship (BS) - 15','Global Health Education Fund','Australia','BS','Pharmacy',18000,'USD','2027-07-19','Sample medical funding for BS students in Pharmacy. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Pharmacy Scholarship (BS) - 15');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Pharmacy' FROM scholarships s
WHERE s.title='Pharmacy Scholarship (BS) - 15' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Pharmacy Scholarship (MS) - 16','Global Health Education Fund','Canada','MS','Pharmacy',8000,'USD','2027-08-20','Sample medical funding for MS students in Pharmacy. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Pharmacy Scholarship (MS) - 16');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Pharmacy' FROM scholarships s
WHERE s.title='Pharmacy Scholarship (MS) - 16' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Public Health Scholarship (MS) - 17','Global Health Education Fund','Türkiye','MS','Public Health',10000,'USD','2027-01-21','Sample medical funding for MS students in Public Health. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Public Health Scholarship (MS) - 17');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Public Health' FROM scholarships s
WHERE s.title='Public Health Scholarship (MS) - 17' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Public Health Scholarship (PhD) - 18','Global Health Education Fund','China','PhD','Public Health',12000,'USD','2027-02-22','Sample medical funding for PhD students in Public Health. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Public Health Scholarship (PhD) - 18');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Public Health' FROM scholarships s
WHERE s.title='Public Health Scholarship (PhD) - 18' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Biomedical Sciences Scholarship (BS) - 19','Global Health Education Fund','Malaysia','BS','Biomedical Sciences',15000,'USD','2027-03-23','Sample medical funding for BS students in Biomedical Sciences. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Biomedical Sciences Scholarship (BS) - 19');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Biomedical Sciences' FROM scholarships s
WHERE s.title='Biomedical Sciences Scholarship (BS) - 19' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Biomedical Sciences Scholarship (MS) - 20','Global Health Education Fund','Italy','MS','Biomedical Sciences',18000,'USD','2027-04-24','Sample medical funding for MS students in Biomedical Sciences. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Biomedical Sciences Scholarship (MS) - 20');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Biomedical Sciences' FROM scholarships s
WHERE s.title='Biomedical Sciences Scholarship (MS) - 20' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Electrical Engineering Scholarship (BS) - 21','Global Engineering Education Fund','United Kingdom','BS','Electrical Engineering',8000,'USD','2027-05-05','Sample engineering funding for BS students in Electrical Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Electrical Engineering Scholarship (BS) - 21');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Electrical Engineering' FROM scholarships s
WHERE s.title='Electrical Engineering Scholarship (BS) - 21' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Electrical Engineering Scholarship (MS) - 22','Global Engineering Education Fund','United States','MS','Electrical Engineering',10000,'USD','2027-06-06','Sample engineering funding for MS students in Electrical Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Electrical Engineering Scholarship (MS) - 22');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Electrical Engineering' FROM scholarships s
WHERE s.title='Electrical Engineering Scholarship (MS) - 22' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Mechanical Engineering Scholarship (MS) - 23','Global Engineering Education Fund','Germany','MS','Mechanical Engineering',12000,'USD','2027-07-07','Sample engineering funding for MS students in Mechanical Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Mechanical Engineering Scholarship (MS) - 23');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Mechanical Engineering' FROM scholarships s
WHERE s.title='Mechanical Engineering Scholarship (MS) - 23' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Mechanical Engineering Scholarship (PhD) - 24','Global Engineering Education Fund','Japan','PhD','Mechanical Engineering',15000,'USD','2027-08-08','Sample engineering funding for PhD students in Mechanical Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Mechanical Engineering Scholarship (PhD) - 24');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Mechanical Engineering' FROM scholarships s
WHERE s.title='Mechanical Engineering Scholarship (PhD) - 24' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Civil Engineering Scholarship (BS) - 25','Global Engineering Education Fund','Australia','BS','Civil Engineering',18000,'USD','2027-01-09','Sample engineering funding for BS students in Civil Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Civil Engineering Scholarship (BS) - 25');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Civil Engineering' FROM scholarships s
WHERE s.title='Civil Engineering Scholarship (BS) - 25' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Civil Engineering Scholarship (MS) - 26','Global Engineering Education Fund','Canada','MS','Civil Engineering',8000,'USD','2027-02-10','Sample engineering funding for MS students in Civil Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Civil Engineering Scholarship (MS) - 26');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Civil Engineering' FROM scholarships s
WHERE s.title='Civil Engineering Scholarship (MS) - 26' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Environmental Engineering Scholarship (MS) - 27','Global Engineering Education Fund','Türkiye','MS','Environmental Engineering',10000,'USD','2027-03-11','Sample engineering funding for MS students in Environmental Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Environmental Engineering Scholarship (MS) - 27');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Environmental Engineering' FROM scholarships s
WHERE s.title='Environmental Engineering Scholarship (MS) - 27' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Environmental Engineering Scholarship (PhD) - 28','Global Engineering Education Fund','China','PhD','Environmental Engineering',12000,'USD','2027-04-12','Sample engineering funding for PhD students in Environmental Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Environmental Engineering Scholarship (PhD) - 28');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Environmental Engineering' FROM scholarships s
WHERE s.title='Environmental Engineering Scholarship (PhD) - 28' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Chemical Engineering Scholarship (BS) - 29','Global Engineering Education Fund','Malaysia','BS','Chemical Engineering',15000,'USD','2027-05-13','Sample engineering funding for BS students in Chemical Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Chemical Engineering Scholarship (BS) - 29');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Chemical Engineering' FROM scholarships s
WHERE s.title='Chemical Engineering Scholarship (BS) - 29' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Chemical Engineering Scholarship (MS) - 30','Global Engineering Education Fund','Italy','MS','Chemical Engineering',18000,'USD','2027-06-14','Sample engineering funding for MS students in Chemical Engineering. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Chemical Engineering Scholarship (MS) - 30');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Chemical Engineering' FROM scholarships s
WHERE s.title='Chemical Engineering Scholarship (MS) - 30' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Business Administration Scholarship (BS) - 31','Global Business Education Fund','United Kingdom','BS','Business Administration',8000,'USD','2027-07-15','Sample business funding for BS students in Business Administration. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Business Administration Scholarship (BS) - 31');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Business Administration' FROM scholarships s
WHERE s.title='Business Administration Scholarship (BS) - 31' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Business Administration Scholarship (MS) - 32','Global Business Education Fund','United States','MS','Business Administration',10000,'USD','2027-08-16','Sample business funding for MS students in Business Administration. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Business Administration Scholarship (MS) - 32');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Business Administration' FROM scholarships s
WHERE s.title='Business Administration Scholarship (MS) - 32' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Economics Scholarship (MS) - 33','Global Business Education Fund','Germany','MS','Economics',12000,'USD','2027-01-17','Sample business funding for MS students in Economics. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Economics Scholarship (MS) - 33');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Economics' FROM scholarships s
WHERE s.title='Economics Scholarship (MS) - 33' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Economics Scholarship (PhD) - 34','Global Business Education Fund','Japan','PhD','Economics',15000,'USD','2027-02-18','Sample business funding for PhD students in Economics. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Economics Scholarship (PhD) - 34');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Economics' FROM scholarships s
WHERE s.title='Economics Scholarship (PhD) - 34' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Finance Scholarship (BS) - 35','Global Business Education Fund','Australia','BS','Finance',18000,'USD','2027-03-19','Sample business funding for BS students in Finance. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Finance Scholarship (BS) - 35');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Finance' FROM scholarships s
WHERE s.title='Finance Scholarship (BS) - 35' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Finance Scholarship (MS) - 36','Global Business Education Fund','Canada','MS','Finance',8000,'USD','2027-04-20','Sample business funding for MS students in Finance. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Finance Scholarship (MS) - 36');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Finance' FROM scholarships s
WHERE s.title='Finance Scholarship (MS) - 36' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Accounting Scholarship (MS) - 37','Global Business Education Fund','Türkiye','MS','Accounting',10000,'USD','2027-05-21','Sample business funding for MS students in Accounting. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Accounting Scholarship (MS) - 37');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Accounting' FROM scholarships s
WHERE s.title='Accounting Scholarship (MS) - 37' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Accounting Scholarship (PhD) - 38','Global Business Education Fund','China','PhD','Accounting',12000,'USD','2027-06-22','Sample business funding for PhD students in Accounting. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Accounting Scholarship (PhD) - 38');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Accounting' FROM scholarships s
WHERE s.title='Accounting Scholarship (PhD) - 38' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Marketing Scholarship (BS) - 39','Global Business Education Fund','Malaysia','BS','Marketing',15000,'USD','2027-07-23','Sample business funding for BS students in Marketing. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Marketing Scholarship (BS) - 39');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Marketing' FROM scholarships s
WHERE s.title='Marketing Scholarship (BS) - 39' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Marketing Scholarship (MS) - 40','Global Business Education Fund','Italy','MS','Marketing',18000,'USD','2027-08-24','Sample business funding for MS students in Marketing. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Marketing Scholarship (MS) - 40');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Marketing' FROM scholarships s
WHERE s.title='Marketing Scholarship (MS) - 40' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Law Scholarship (BS) - 41','Global Social Sciences Education Fund','United Kingdom','BS','Law',8000,'USD','2027-01-05','Sample social sciences funding for BS students in Law. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Law Scholarship (BS) - 41');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Law' FROM scholarships s
WHERE s.title='Law Scholarship (BS) - 41' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Law Scholarship (MS) - 42','Global Social Sciences Education Fund','United States','MS','Law',10000,'USD','2027-02-06','Sample social sciences funding for MS students in Law. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Law Scholarship (MS) - 42');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Law' FROM scholarships s
WHERE s.title='Law Scholarship (MS) - 42' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Education Scholarship (MS) - 43','Global Social Sciences Education Fund','Germany','MS','Education',12000,'USD','2027-03-07','Sample social sciences funding for MS students in Education. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Education Scholarship (MS) - 43');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Education' FROM scholarships s
WHERE s.title='Education Scholarship (MS) - 43' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Education Scholarship (PhD) - 44','Global Social Sciences Education Fund','Japan','PhD','Education',15000,'USD','2027-04-08','Sample social sciences funding for PhD students in Education. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Education Scholarship (PhD) - 44');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Education' FROM scholarships s
WHERE s.title='Education Scholarship (PhD) - 44' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Psychology Scholarship (BS) - 45','Global Social Sciences Education Fund','Australia','BS','Psychology',18000,'USD','2027-05-09','Sample social sciences funding for BS students in Psychology. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Psychology Scholarship (BS) - 45');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Psychology' FROM scholarships s
WHERE s.title='Psychology Scholarship (BS) - 45' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Psychology Scholarship (MS) - 46','Global Social Sciences Education Fund','Canada','MS','Psychology',8000,'USD','2027-06-10','Sample social sciences funding for MS students in Psychology. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Psychology Scholarship (MS) - 46');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Psychology' FROM scholarships s
WHERE s.title='Psychology Scholarship (MS) - 46' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Agriculture Scholarship (MS) - 47','Global Social Sciences Education Fund','Türkiye','MS','Agriculture',10000,'USD','2027-07-11','Sample social sciences funding for MS students in Agriculture. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Agriculture Scholarship (MS) - 47');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Agriculture' FROM scholarships s
WHERE s.title='Agriculture Scholarship (MS) - 47' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Agriculture Scholarship (PhD) - 48','Global Social Sciences Education Fund','China','PhD','Agriculture',12000,'USD','2027-08-12','Sample social sciences funding for PhD students in Agriculture. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Agriculture Scholarship (PhD) - 48');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','PhD','Agriculture' FROM scholarships s
WHERE s.title='Agriculture Scholarship (PhD) - 48' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Environmental Science Scholarship (BS) - 49','Global Social Sciences Education Fund','Malaysia','BS','Environmental Science',15000,'USD','2027-01-13','Sample social sciences funding for BS students in Environmental Science. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Environmental Science Scholarship (BS) - 49');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','BS','Environmental Science' FROM scholarships s
WHERE s.title='Environmental Science Scholarship (BS) - 49' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

INSERT INTO scholarships (university_id,title,provider,country,degree_level,field_of_study,amount,currency,deadline,description,application_url,status)
SELECT NULL,'Environmental Science Scholarship (MS) - 50','Global Social Sciences Education Fund','Italy','MS','Environmental Science',18000,'USD','2027-02-14','Sample social sciences funding for MS students in Environmental Science. This is illustrative data created for the academic project, not a verified live offer. Confirm current availability, eligibility, award value and deadline with the provider.','https://example.org/scholarships','Open'
WHERE NOT EXISTS (SELECT 1 FROM scholarships WHERE title='Environmental Science Scholarship (MS) - 50');
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT scholarship_id,2.50,'Any','MS','Environmental Science' FROM scholarships s
WHERE s.title='Environmental Science Scholarship (MS) - 50' AND NOT EXISTS (SELECT 1 FROM eligibility_rules er WHERE er.scholarship_id=s.scholarship_id);

-- Add a default eligibility rule to any older scholarship without one.
INSERT INTO eligibility_rules (scholarship_id,min_cgpa,eligible_country,required_degree,required_field)
SELECT s.scholarship_id,0,'Any',s.degree_level,s.field_of_study
FROM scholarships s LEFT JOIN eligibility_rules er ON er.scholarship_id=s.scholarship_id
WHERE er.eligibility_id IS NULL;

-- Normalize legacy degree labels.
UPDATE eligibility_rules SET required_degree='BS' WHERE LOWER(required_degree) IN ('bachelor','bachelors','bachelor''s','undergraduate');
UPDATE eligibility_rules SET required_degree='MS' WHERE LOWER(required_degree) IN ('master','masters','master''s','mphil');
UPDATE eligibility_rules SET required_degree='PhD' WHERE LOWER(required_degree) IN ('ph.d','doctorate','doctoral');

-- Advanced DBMS queries
SELECT s.title, u.university_name, s.country, s.degree_level
FROM scholarships s
LEFT JOIN universities u ON s.university_id=u.university_id;

SELECT full_name,cgpa FROM students
WHERE cgpa > (SELECT AVG(cgpa) FROM students);

SELECT country,COUNT(*) AS scholarship_count
FROM scholarships GROUP BY country;

SELECT COUNT(*) AS total_students FROM students;
SELECT AVG(cgpa) AS average_cgpa FROM students;
SELECT MAX(amount) AS maximum_award FROM scholarships;

CREATE OR REPLACE VIEW available_scholarships AS
SELECT scholarship_id,title,country,degree_level,field_of_study,amount,currency,deadline
FROM scholarships
WHERE status='Open' AND deadline >= CURDATE();

-- Stored procedure for profile-based scholarship matching.
DROP PROCEDURE IF EXISTS search_scholarships;
DELIMITER //
CREATE PROCEDURE search_scholarships(
 IN p_student_country VARCHAR(60),
 IN p_degree VARCHAR(50),
 IN p_field VARCHAR(100),
 IN p_cgpa DECIMAL(3,2),
 IN p_destination_country VARCHAR(60)
)
BEGIN
 SELECT DISTINCT s.scholarship_id,s.title,s.provider,s.country,s.degree_level,
        s.field_of_study,s.amount,s.currency,s.deadline,s.application_url
 FROM scholarships s
 JOIN eligibility_rules er ON er.scholarship_id=s.scholarship_id
 WHERE s.status='Open' AND s.deadline >= CURDATE()
   AND (er.eligible_country='Any' OR LOWER(er.eligible_country)=LOWER(p_student_country))
   AND (er.required_degree='Any' OR LOWER(er.required_degree)=LOWER(p_degree))
   AND (er.required_field='Any' OR LOWER(er.required_field)=LOWER(p_field)
     OR (LOWER(p_field) IN ('it','technology','computer','computing','computer science','information technology')
         AND LOWER(er.required_field) IN ('computer science','information technology','software engineering','data science','artificial intelligence'))
     OR (LOWER(p_field) IN ('medical','medicine','health','health sciences')
         AND LOWER(er.required_field) IN ('medicine','nursing','pharmacy','public health','biomedical sciences'))
     OR (LOWER(p_field)='engineering'
         AND LOWER(er.required_field) IN ('electrical engineering','mechanical engineering','civil engineering','environmental engineering','chemical engineering'))
     OR (LOWER(p_field) IN ('business','management')
         AND LOWER(er.required_field) IN ('business administration','economics','finance','accounting','marketing'))
     OR (LOWER(p_field)='social sciences'
         AND LOWER(er.required_field) IN ('law','education','psychology','agriculture','environmental science')))
   AND COALESCE(er.min_cgpa,0) <= p_cgpa
   AND s.country LIKE CONCAT('%',p_destination_country,'%')
 ORDER BY s.deadline;
END //
DELIMITER ;

-- Trigger
DROP TRIGGER IF EXISTS set_application_date;
DELIMITER //
CREATE TRIGGER set_application_date
BEFORE INSERT ON applications
FOR EACH ROW
BEGIN
 IF NEW.application_date IS NULL THEN
  SET NEW.application_date = CURDATE();
 END IF;
END //
DELIMITER ;

-- Example procedure call:
-- CALL search_scholarships('Pakistan','BS','Computer Science',3.20,'');
-- Example view:
-- SELECT * FROM available_scholarships;
