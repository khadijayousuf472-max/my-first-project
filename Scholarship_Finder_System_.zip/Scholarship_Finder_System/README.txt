# Scholarship Finder System

A beginner-friendly DBMS desktop project using Python Tkinter and MySQL (XAMPP).

## Requirements
- Windows
- Python 3
- XAMPP with MySQL running
- MySQL Workbench (optional, for viewing and demonstrating SQL)
- VS Code (optional)

## Setup
1. Extract this folder.
2. Open XAMPP Control Panel and start **MySQL**. Apache is not required by this Python desktop app.
3. Open a terminal in this project folder.
4. Install the Python connector:
   `py -m pip install -r requirements.txt`
5. Run:
   `py main.py`

The app creates the `scholarship_finder` database and tables automatically on first run and inserts 50 sample scholarship records with 10 entries each across Technology, Medical, Engineering, Business and Social Sciences. The sample catalogue is inserted only once; existing records are retained.
It uses the usual XAMPP defaults: host localhost, user root, blank password, port 3306.
If your MySQL root account has a password or uses another port, edit DB_CONFIG at the top of main.py.

## Demo admin login
- Username: admin
- Password: Admin@123

Students can register through Student Registration.

## Included features
- Student registration and login
- Smart scholarship matching by student degree, field, nationality and CGPA
- 50 preloaded sample scholarship records across multiple academic fields
- Admin eligibility rules with multiple degrees/fields and minimum CGPA
- Apply for a scholarship
- View personal applications and status
- Admin dashboard
- Add, update and delete scholarships
- View registered students
- Update application status
- SQL schema, relationships, view, trigger, procedure and example queries

## Important notes
- All 50 preloaded scholarships are demonstration records, not verified live offers. Their deadlines, amounts and example links are illustrative. Verify real opportunities with providers before applying.
- This is an academic demonstration project, not a production system.
- The demo admin password should be changed before any real deployment.
- The app stores SHA-256 password hashes for a classroom demo. For a real production system, use a password-specific algorithm such as Argon2 or bcrypt.
